# catalog/serializers/__init__.py
from .category import CategorySerializer  # noqa: F401
from .product import ProductSerializer    # noqa: F401
